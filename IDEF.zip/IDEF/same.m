function flag = same(D,Dold)
% 1是完全相同 0 不同
flag= 1;
% 列是规则数
if size(D,2)==size(Dold,2)
    for i = 1:size(D,2)
        % 有一个不同的就跳出
        if ~isequal(D(:,i),Dold(:,i))
            flag = 0;
            break;
        end
    end
end


