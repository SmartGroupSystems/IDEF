function deles = calCost2(A)

paiming = zeros(size(A));%从大到小 1...100
% 遍历每一行
for aa = 1:size(A,1)
    thishang = A(aa,:);
    thisrank = 1;
    while sum(thishang)~=-500*length(thishang)
        thismax = max(thishang);
        maxinds = find(thishang == thismax);
        paiming(aa,maxinds) = thisrank;
        thisrank = thisrank + length(maxinds);
        thishang(maxinds) = -500;
    end
end
repaiming = size(A,2)+ 1- paiming; % 逆序，从小到大是1.。。100
% 删除排序不为max的个体。遍历每一列
maxvalue = size(A,2);% 注意每行最大值一定是算法个数！！因为是从8开始倒数的！
deles = [];
for dd = 1:maxvalue
    if max(repaiming(:,dd))<maxvalue
        deles = [deles dd];
    end
end
