function [deleted] = compareI(THETA_F2_Iall, remain_num_ins)
% 行为问题个数，列为规则个数
%% 每一行是一个个体的目标函数
deleted = [];
len = size(THETA_F2_Iall,1);
kexuan = 1:1:len;

delenums = len - remain_num_ins;
for nn = 1: delenums
    % 从population随机选择当2个存到 待选集合nGEA里
    templen = size(THETA_F2_Iall,1);
    nGEA0 = randperm(templen, 2);
    a = THETA_F2_Iall(nGEA0(1),:);
    b = THETA_F2_Iall(nGEA0(2),:);
    compareflag = DominatesF3(a, b); % 2是前胜  1是后胜， 0是互不支配
    if compareflag>0
        %% 删除较差的，与ALL2中正好相反
        dele = nGEA0(compareflag);
        nGEA = kexuan(dele);
        deleted = [deleted nGEA];
    else
        % a好
        best1 = max(a);
        best2 = max(b);
        % 则选择两个算例中最优算法对应目标函数值较大的个体为较差个体
        if best1 > best2
            dele = nGEA0(1);
            nGEA = kexuan(dele);
            deleted = [deleted nGEA];
        else
            dele = nGEA0(2);
            nGEA = kexuan(dele);
            deleted = [deleted nGEA];
        end
    end
    THETA_F2_Iall(dele,:) = [];
    kexuan(dele) = [];
end


