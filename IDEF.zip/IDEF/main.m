%% 主程序运行入口
clear
clc

totalTimes = 500;
step = 64;
st = 1;

I_MAXLEN = step/8;
I_NEWLEN = step/8;


I = [1 : 1 : step];
lei = [1:1:step];
Itotal = I;
startind = step+1;

[totalpara, totalcan, zongpara, totalmaxvalues] = initpara(Itotal);


g = ones(1,step)./step;


zongpara.insnum = length(I);
[THETA, THETA_F2_I] = main1(1, totalpara, totalcan, zongpara, totalmaxvalues);
unchange = 0;
THETA_F2_Itotal = THETA_F2_I;

for times = 2:500

    [paranew, newlei, maxvalues_Inew] = newinsGenerate(g, I_NEWLEN, step);
    Inew = [startind:1:startind + I_NEWLEN-1];
    startind = startind + I_NEWLEN;
    


    [THETA_F2_newI, cannew] = constructI(THETA, paranew, zongpara, maxvalues_Inew);


    poss = find(ismember(Itotal, I));
    THETA_F2_I = THETA_F2_Itotal(poss,:);
    THETA_F2_Iall = [THETA_F2_I; THETA_F2_newI];
    [deleted] = compareI(THETA_F2_Iall, I_MAXLEN);
    deleted2 = deleted(deleted>length(I));
    c = deleted2-length(I);

    Iall = [I, Inew];
    Iall(deleted) = [];
    I = Iall;

    Inew(c) = [];
    Ires_theta = Inew;

    THETA_F2_newI(c,:) = [];
    THETA_F2_Itotal = [THETA_F2_Itotal; THETA_F2_newI];

    Itotal = [Itotal Ires_theta];





    alllei = [lei, newlei];
    alllei(deleted) = [];
    lei = alllei;

    paranew(c) = [];
    totalpara = [totalpara paranew];
    cannew(c) = [];
    totalcan = [totalcan cannew];
    maxvalues_Inew(c) = [];
    totalmaxvalues = [totalmaxvalues; maxvalues_Inew];





    cc = tabulate(lei);
    bili = cc(:,3);
    bili = bili';
    if length(bili)<step
        bili = [bili zeros(1,step-length(bili))];
    end
    g = g + (bili./100-g)./totalTimes;





    poss = find(ismember(Itotal, I));
    res_poss = find(~ismember(Itotal, I));

    para_I = totalpara(poss);
    can_I = totalcan(poss);
    maxvalues_I = totalmaxvalues(poss);
    zongpara.insnum = length(I);
    
    [THETAnew, THETAnew_F2_I] = main1(times, para_I, can_I, zongpara, maxvalues_I);

    THETAnew_F2_Itotal = zeros(length(Itotal), size(THETAnew,2));
    THETAnew_F2_Itotal(poss,:) = THETAnew_F2_I;
    Ires_theta = Itotal(res_poss);
    for n = 1:length(Ires_theta)
        thispos = res_poss(n);
        bianhao = Ires_theta(n);
        THETAnew_F2_Itotal(thispos,:) = construct(THETAnew, totalpara(thispos), zongpara, totalcan(thispos), totalmaxvalues(thispos));
    end



    oldtheta = THETA;

    THETA = [THETA THETAnew];
    THETA_F2_Itotal = [THETA_F2_Itotal THETAnew_F2_Itotal];

    deles2 = calCost2(THETA_F2_Itotal);
    THETA(: , deles2) = [];
    THETA_F2_Itotal(: , deles2) =[];

    leis = [];
    for ii = 1:length(Itotal)
        leis(ii) = mod(Itotal(ii)-1, step)+1;
    end

    leftind = zeros(1,step);
    for ll = 1: step
        thisinsset = find(leis == ll);
        thisTHETA_F2_Itotal = THETA_F2_Itotal(thisinsset,:);
        thiscost = calCost3(thisTHETA_F2_Itotal);
        [~,ind] = max(thiscost);
        leftind(ll) = ind;
    end
    leftind2 = unique(leftind);
    THETA = THETA(:,leftind2);
    THETA_F2_Itotal = THETA_F2_Itotal(:,leftind2);


    flag = same(THETA, oldtheta);

    if flag == 1
        unchange = unchange + 1;
    else
        unchange = 0;
    end



    namest = ['C:\Users\lenovo\Desktop\HH\results\\GAE9-8_thetaw.xlsx'];
    writematrix(THETA', namest,'Sheet',times);



    if unchange > 50 || times == 500


        namest = ['C:\Users\lenovo\Desktop\HH\results\\final_theta-8w.xlsx'];
        writematrix(THETA,namest,'Sheet',1);
    end






end