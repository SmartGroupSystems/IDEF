%% F2越大越好 2是后胜，1是前胜 0 是互不支配
function b = DominatesF2(x,y)

b = 0;
if all(x<=y) && any(x<y)
    b = 2;  % y大，说明y主导
elseif all(x>=y) && any(x>y)
    b = 1;
end

end