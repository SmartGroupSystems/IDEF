function [convergefit,finalquanzhi] = main2(para,can,zongpara)

%% 返回这一次的解和时间
% tic
[convergefit, finalquanzhi] = shade(para,can,zongpara);
% runtime = toc;

convergefit = convergefit';
disp("*****one simulation finished!*********");

% ranges = ['A',num2str(times)];
% %% 1、fitness值
% ranges = ['A',num2str(times)];
% names1 = ['C:\Users\lenovo\Desktop\时间窗约束\codeslixian\results\\shadefits.xlsx'];
% writematrix(fit,names1,'Sheet',ins,'Range',ranges);
% %% 2、 运行时间
% names2 = ['C:\Users\lenovo\Desktop\时间窗约束\codeslixian\results\\shaderuntimes.xlsx'];
% writematrix(runtime,names2,'Sheet',ins,'Range',ranges);
% 
% 
% names3 = ['C:\Users\lenovo\Desktop\时间窗约束\codeslixian\results\\shadequanzhi.xlsx'];
% writematrix(w,names3,'Sheet',ins,'Range',ranges);

% 计算解
% sol = fCalFitnessbig(w,para);
% names4 = ['C:\Users\lenovo\Desktop\时间窗约束\codeslixian\results\\shadeguanxi.xlsx'];
% writematrix(sol(1,:),names4,'Sheet',ins,'Range',ranges);
% names5 = ['C:\Users\lenovo\Desktop\时间窗约束\codeslixian\results\\shadetime.xlsx'];
% writematrix(sol(2,:),names5,'Sheet',ins,'Range',ranges);



% names7 = ['C:\Users\lenovo\Desktop\时间窗约束\codeslixian\results\\convergesolpbil.xlsx'];
% writematrix(convergequanzhi,names7,'Sheet',ins,'Range',ranges);

% % writematrix(tm,names3,'Sheet',3,'Range',ranges);

% % % 画执行图
% tm = [];
% for e = 1:length(solution)
%     index = solution(e);
%     target = floor((index-1)/para.W) + 1;
%     weapon = index - (target-1)*para.W;
%     tm(e) = tf(e)+para.TE(weapon,target);
% end
% mDuration = tm - tf;
% drawGanttChart(solution, tf, mDuration, para.W, para.T,ins)

end


function drawGanttChart(events, startTimes1, durations1,W,T,ins)
c1 = [0 0.4470 0.7410]; % 深蓝

c4 = [0 1 0];% 绿
c5 = [0.4660 0.6740 0.1880];% 浅绿
c6 = [0.3010 0.7450 0.9330]; % 蓝
c7 = [0.6350 0.0780 0.1840]; %红
c8 = [0 0 0];% black

yfig = figure('Visible', 'off');
% 绘制甘特图
events_label = {}; % w1w2w3w4 w1w2w3w4
totalevents = W*T;
for e = 1:totalevents
    weapon = mod((e-1),W)+1;
    target = floor((e-1)/W)+1;
    events_label{e} = ['r',num2str(weapon),' to t',num2str(target)];
end
set(gcf,'Position',get(0,'Screensize')); %将图像全屏显示
xlim([0, 250]);
ylim([0, totalevents+0.5]);
set(gca,'xtick',0:10:250);
set(gca,'ytick',1:1:totalevents);

set(gca,'yticklabel',events_label);

if totalevents>=100
    set(gca,'yticklabel',events_label,'Fontsize',6);
end
% set([Yticklabel],'Fontsize',6);



numEvents = length(events);
for i = 1:numEvents
    % 绘制矩形条
    rectangle('Position', [startTimes1(i), events(i)-0.3, durations1(i), 0.6], 'FaceColor', c4);

    %     % 添加任务标签
    %     Text(startTimes1(i), i, tasks(i), 'VerticalAlignment', 'middle', 'HorizontalAlignment', 'right');
end



% 设置图形属性
% ylim([0, numEvents + 0.5]);
% aa = startTimes2+durations2;


xlabel('时间(s)','FontSize',16);
ylabel('匹配对','FontSize',16);
title('匹配对及执行时间窗','FontSize',16);
grid on;



%% 保存图片
name1 =  ['C:\Users\lenovo\Desktop\时间窗约束\codes\results_guanxi\',num2str(ins),'.png'];
print(yfig,name1,'-dpng','-r300');         % 指定保存路径
end

