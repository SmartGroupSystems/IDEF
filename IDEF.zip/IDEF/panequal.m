function [isdominated] = panequal(THETAnew_F2_I)
% 行为问题个数，列为规则个数
%% 每一列是一个个体的目标函数
%比较Θnew中每个元素θnew，保留互不支配且F2不同的θnew为Θnew。
isdominated = [];
for i = 1 : size(THETAnew_F2_I, 2)-1
    a = THETAnew_F2_I(:,i);
    for j = i+1 : size(THETAnew_F2_I, 2)
        b = THETAnew_F2_I(:,j);
        if a == b
            compareflag = randi([1,2]);
        else
            compareflag = DominatesF2(a, b); % 1是前胜  2是后胜， 0是互不支配
        end
        
        if compareflag == 1
            isdominated = [isdominated j];
        elseif compareflag == 2
            isdominated = [isdominated i];
        end
    end
end
