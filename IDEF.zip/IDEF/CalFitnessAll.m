function [Fitness] = CalFitnessAll(quanzhi, para,can,zongpara,maxvalues)

fitness = zeros(zongpara.insnum,1);
parfor ins = 1: zongpara.insnum
    fitness(ins) = CalFitnessbigTT(quanzhi,para(ins),can(ins),zongpara);
end
% 归一化求平均
Fitness1 = fitness./maxvalues;
Fitness = roundn(Fitness1, -3);
end