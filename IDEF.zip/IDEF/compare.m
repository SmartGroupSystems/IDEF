function [isdominated] = compare(THETA_F2_I)
% 行为问题个数，列为规则个数
%% 每一列是一个个体的目标函数


isdominated = [];
for i = 1: size(THETA_F2_I, 2)
    thetai = THETA_F2_I(:,i);
    for j = i+1: size(THETA_F2_I, 2)
        thetaj = THETA_F2_I(:,j);
        % 若θnew与θ的F2完全相同，证明该θnew没必要增加；
        if thetaj == thetai
            isdominated = [isdominated j];
            continue;
        else
            compareflag = DominatesF2(thetai, thetaj); % 1是前胜i好  2是后胜， 0是互不支配
            if compareflag == 1 % 如果thetai 支配thetaj
                isdominated = [isdominated j];
            elseif compareflag == 2
                isdominated = [isdominated i];
            end
        end

    end
end




