function [Fitness] = CalFitnessbigTT(quanzhi,para,can,zongpara)
% nvar是判据个数(网络输入维度)，nvar1是中心点向量总维度，nvar2是神经元输出权值维度（就是神经元个数）
spread = zongpara.spread;
W = para.W;
T = para.T;
wcenters = quanzhi(1:zongpara.nvar1);
wweights = quanzhi(zongpara.nvar1+1:end);
%% 将神经元的矩阵重新排列
centers = zeros(zongpara.nvar2, zongpara.nvar);
% 遍历每个神经元
for cc = 1:zongpara.nvar2
    centers(cc,:) = wcenters((cc-1)*zongpara.nvar+1 : cc*zongpara.nvar);
end



%% 初始化解
mPosition = []; % 分配关系
% mTF = [];  % 分配时刻（开始执行时刻）
% mTM = [];
mP = []; % SS概率
TE = para.TE;
types = para.P_type;

tempV = para.V;
PH = ones(W,T);

% 计算初始PH time
origin_maxtime = zeros(W, T);
for i = 1:W
    for j = 1:T
        % 递增
        if types(i,j) == 1
            origin_maxtime(i,j) = para.TM(i,j)+para.LEN(i,j);
            % 递减
        elseif types(i,j) == 2
            origin_maxtime(i,j) = para.TM(i,j);
            % 中间
        else
            origin_maxtime(i,j) = roundn(para.TM(i,j)+para.LEN(i,j)/2 ,-2);
        end
    end
end



% 能力上限约束
N = zeros(W, 1);
lk = zeros(1,T);

% 可执行时间窗约束 + 并行能力约束 + 准备时间约束 + 策略约束
% 注意，执行时长TE是不会变化的！！！ 只有TF TM LEN变化了
TF = cell(W, T);
LEN = cell(W, T);


for i = 1:W
    for j = 1:T
        TF{i,j} = para.TF(i,j);
        LEN{i,j} = para.LEN(i,j);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 2、循环
times = 1;
panju = can.panju;
fuzhuindex = can.fuzhuindex;
fuzhuptime = can.fuzhuptime;
fuzhuweapon = can.fuzhuweapon;
fuzhutarget = can.fuzhutarget;
% 注意这里PH的数值没有意义了，只计算其0的位置和数目
while (sum(PH(:))>0)

    %% 2.1 更新max，归一化判据，计算JC2
    % 后续次数，归一化+计算JC
    if times>1
        numofpairs = size(panju,1);


        %2、 更新每列最大值
        maximum = max(panju,[],1);
        for mm = 1:zongpara.nvar
            % 此时max应该全都是正负数，没有0；
            % 若max=0，说明该列元素全=0，则所有匹配对该判据相等，所以不归一化也可以了，max取1
            % 这样所有的max都不是0，不用担心分母=0
            if maximum(mm) == 0
                maximum(mm) = 1;
            end
        end


        % 归一化判据
        npanju = panju./maximum;


        %% RBF网络
        JC = zeros(1, numofpairs) - 100;
        % 遍历每一个pair
        for aa = 1: numofpairs
            input = npanju(aa,:);
            %             rbf_values = zeros(para.nvar2, 1);
            % 循环计算每个神经元的输出值(共h个)
            %             for ee = 1:para.nvar2
            %                 % 计算每个判据与神经元中心向量的距离
            %                 chazhi = input - centers(ee,:);
            %                 distances = sum(chazhi.^2);
            %                 % 注意前面没有开根号，所以后面省去了平方
            %                 % 通过高斯径向基函数计算RBF神经元的激活值
            %                 rbf_values(ee,1) = exp(- (distances) / (2 * spread^2));
            %             end


            % 计算每个判据与神经元中心向量的距离
            chazhi = input - centers;
            distances = sum(chazhi.^2, 2); % 每行求和
            % 注意前面没有开根号，所以后面省去了平方
            % 通过高斯径向基函数计算RBF神经元的激活值
            rbf_values = exp(- distances ./ (2 * spread^2));

            % 计算该判据的网络输出值（加权和）
            JC(aa) = sum(wweights .* rbf_values); %nvar2*1——nvar2*1
        end

        % 第一次，只计算JC，不用归一化
    else
        % panju一开始肯定没有0行！
        %% RBF网络
        % 遍历每一个pair
        numofpairs = size(can.npanju,1);
        JC = zeros(1, numofpairs) - 100;
        
        for aa = 1: numofpairs
            input = can.npanju(aa,:);
            %             rbf_values = zeros(para.nvar2, 1);
            % 循环计算每个神经元的输出值(共h个)
            %             for ee = 1:para.nvar2
            %                 % 计算每个判据与神经元中心向量的距离
            %                 chazhi = input - centers(ee,:);
            %                 distances = sum(chazhi.^2);
            %                 % 注意前面没有开根号，所以后面省去了平方
            %                 % 通过高斯径向基函数计算RBF神经元的激活值
            %                 rbf_values(ee) = exp(- (distances) / (2 * para.spread^2));
            %             end

            % 计算每个判据与神经元中心向量的距离
            chazhi = input - centers;
            distances = sum(chazhi.^2, 2); % 每行求和
            % 注意前面没有开根号，所以后面省去了平方
            % 通过高斯径向基函数计算RBF神经元的激活值
            rbf_values = exp(- distances ./ (2 * spread^2));

            % 计算该判据的网络输出值（加权和）
%             cc = sum(wweights' .* rbf_values)
            JC(aa) = sum(wweights .* rbf_values); %nvar2*1——nvar2*1
            
        end
    end


    %% 2.2 选取JC中最大元素maxElement
    [~, index] = max(JC);

    thisindex = fuzhuindex(index);
    target = floor((thisindex-1)/W) + 1;
    weapon = thisindex - (target-1)*W;

    %% 2.3 在分配关系中加入该元素
    mPosition = [mPosition, thisindex];

    %% 2.4 分配时刻
    % 获取最大元素对应的完成时刻, 加入解中
    endtime = fuzhuptime(index);
    starttime = endtime-TE(weapon, target);
    %% 分配时刻中加入该元素
%     mTF = [mTF, starttime];
%     mTM = [mTM, endtime];
    %% ss概率中加入该元素
    mP = [mP, panju(index,2)];

    tempV(target) = tempV(target)*(1-panju(index,2));




    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%更新约束！
    %% 3.1 更新数目类约束——资源能力上限约束


    timechange = zeros(W,T); %% 这里只记录时间窗变化的  0表示没变化，1表示变化 注意时间窗消失的也为0!

    N(weapon, 1) = N(weapon, 1) + 1;
    Nflag = 1;

    lk(1,target) = lk(1,target) + 1;
    lkflag = 1;

    % 针对 数目约束 不可行的武器，使其PH 为0
    if N(weapon, 1) >= para.N(weapon,1)
        PH(weapon,:) = 0;

        Nflag = 0;
        for j = 1:T
            TF{weapon,j} = [];
            LEN{weapon,j} = [];
        end
    end

    %% 新增！ 任务可用资源数目上限约束
    if lk(1,target) >= para.lk(1,target)
        PH(:,target) = 0;

        lkflag = 0;
        for i = 1:W
            TF{i,target} = [];
            LEN{i,target} = [];
        end
    end

    %% 3.2 更新时间类约束——并行执行能力、准备时间约束、策略约束
    % 更新本武器对所有目标的时间窗
    if Nflag
        Lmin = starttime - para.deta(weapon,1);
        Lmax = starttime + para.deta(weapon,1);

        for t = 1:T
            % 该分配关系不可用
            if PH(weapon,t) == 0
                continue;
            end

            thisTF = TF{weapon,t};

            %% 2、准备时间约束
            flagAdd2 = 0;
            flagDelete2 = [];


            TFadd2 = [];
            LENadd2 = [];


            for nn = 1:length(thisTF)
                t1 = thisTF(nn);
                t2 = t1 + LEN{weapon,t}(nn);

                % 砍后半段，起点不变, 长度变，结尾变
                if t1<Lmin && t2>Lmin && t2<=Lmax
                    LEN{weapon,t}(nn) = Lmin-t1;

                    if Lmin-t1<0.1
                        flagDelete2(end+1) = nn;
                    else
                        timechange(weapon,t) = 1;
                    end



                elseif t1>=Lmin && t2<=Lmax % 删除
                    flagDelete2(end+1) = nn;
                    % 砍前半段，起点变，长度变，结尾不变
                elseif t1>=Lmin && t1<Lmax && t2>Lmax
                    LEN{weapon,t}(nn) = t2-Lmax;
                    TF{weapon,t}(nn) = Lmax;
                    %

                    if t2-Lmax<0.1
                        flagDelete2(end+1) = nn;
                    else
                        timechange(weapon,t) = 1;
                    end

                    % 砍两段
                elseif t1<Lmin && t2>Lmax

                    % 两个都有
                    if Lmin-t1>0.1 && t2-Lmax>0.1

                        % 1前——砍后半段，起点不变, 长度变，结尾变
                        LEN{weapon,t}(nn) = Lmin-t1;

                        % 2后，增加——砍前半段，起点变，长度变，结尾不变
                        flagAdd2 = 1;
                        LENadd2 = [LENadd2, t2-Lmax];
                        TFadd2 = [TFadd2, Lmax];


                        timechange(weapon,t) = 1;
                        % 只有前面的
                    elseif Lmin-t1>0.1 && t2-Lmax<=0.1
                        % 1前——砍后半段，起点不变, 长度变，结尾变
                        LEN{weapon,t}(nn) = Lmin-t1;


                        timechange(weapon,t) = 1;
                        % 只有后面的
                    elseif Lmin-t1<=0.1 && t2-Lmax>0.1
                        % 2后，——砍前半段，起点变，长度变，结尾不变
                        LEN{weapon,t}(nn) =  t2-Lmax;
                        TF{weapon,t}(nn) =  Lmax;

                        timechange(weapon,t) = 1;

                    else
                        flagDelete2(end+1) = nn;
                    end

                end

            end
            % 先增
            if flagAdd2
                [TF{weapon,t}, shunxu] = sort([TF{weapon,t} TFadd2]);
                LEN{weapon,t} = [LEN{weapon,t} LENadd2];
                LEN{weapon,t} = LEN{weapon,t}(shunxu);
            end
            % 后减
            if ~isempty(flagDelete2)

                TF{weapon,t}(flagDelete2) = [];
                LEN{weapon,t}(flagDelete2) = [];

                if isempty(TF{weapon,t})
                    PH(weapon,t) = 0;
                    timechange(weapon,t) = 0;
                else
                    timechange(weapon,t) = 1;
                end
            end

        end
    end



    %% 3.3 根据策略约束更新本任务时间窗
    % 注意这里只考虑mk=1的情况，等价于不重叠！
    if lkflag
        for w = 1:W

            if PH(w,target) == 0
                continue;
            end
            L = starttime;
            H = endtime;
            thisTF = TF{w,target};

            flagAdd = 0;
            flagDelete = [];
            TFadd = [];
            LENadd = [];


            for nn = 1:length(thisTF)
                t1 = thisTF(nn);
                t2 = t1 + LEN{w,target}(nn);

                % 注意TE不会变
                t3 = t1+TE(w,target);
                t4 = t2+TE(w,target);


                % 砍TM后半段(TF也被砍) ，起点不变, 长度变，结尾变
                if t3<L && t4>L && t4<=H
                    LEN{w,target}(nn) = L-t3;



                    if L-t3<0.1
                        flagDelete(end+1) = nn;
                    else
                        timechange(w,target) = 1;
                    end

                elseif t3>=L && t4<=H
                    flagDelete(end+1) = nn;
                elseif t3>=L && t3<H && t4>H
                    % 4.1
                    if t2<=H
                        flagDelete(end+1) = nn;
                        % 4.2 砍TF前半段 起点变，长度变，结尾不变
                    elseif t2>H
                        LEN{w,target}(nn) = t2-H;
                        TF{w,target}(nn) = H;


                        if t2-H<0.1
                            flagDelete(end+1) = nn;
                        else
                            timechange(w,target) = 1;
                        end

                    end
                elseif t3<L && t4>H
                    % 5.1砍TM后半段 起点不变, 长度变，结尾变
                    if t2<=H
                        LEN{w,target}(nn) = L-t3;


                        if L-t3<0.1
                            flagDelete(end+1) = nn;
                        else
                            timechange(w,target) = 1;
                        end


                        % 5.2 砍两段
                    elseif t2>H

                        % 两个都有
                        if  L-t3>0.1 && t2-H>0.1

                            % 前-砍TM后半段 起点不变, 长度变，结尾变
                            LEN{w,target}(nn) = L-t3;


                            % 后，增加-砍TF前半段，起点变，长度变，结尾不变
                            flagAdd = 1;
                            LENadd = [LENadd, t2-H];
                            TFadd = [TFadd, H];


                            timechange(w,target) = 1;
                            % 只有前面的
                        elseif  L-t3>0.1 && t2-H<=0.1
                            % 1前——砍后半段，起点不变, 长度变，结尾变
                            LEN{w,target}(nn) = L-t3;


                            timechange(w,target) = 1;
                            % 只有后面的
                        elseif L-t3<=0.1 && t2-H>0.1
                            % 2后，——砍前半段，起点变，长度变，结尾不变
                            LEN{w,target}(nn) = t2-H;
                            TF{w,target}(nn) = H;

                            timechange(w,target) = 1;
                        else
                            flagDelete(end+1) = nn;
                        end
                    end
                elseif t3>=H
                    if t2<=H
                        flagDelete(end+1) = nn;
                        % 6.2砍TF前
                    elseif t2>H && t1<H
                        LEN{w,target}(nn) = t2-H;
                        TF{w,target}(nn) = H;

                        if t2-H<0.1
                            flagDelete(end+1) = nn;
                        else
                            timechange(w,target) = 1;
                        end
                    end
                end
            end

            if flagAdd


                [TF{w,target}, shunxu] = sort([TF{w,target} TFadd]);
                LEN{w,target} = [LEN{w,target} LENadd];
                LEN{w,target} = LEN{w,target}(shunxu);

            end
            if ~isempty(flagDelete)

                TF{w,target}(flagDelete) = [];
                LEN{w,target}(flagDelete) = [];

                if isempty(TF{w,target})
                    PH(w,target) = 0;

                    timechange(w,target) = 0;
                else
                    timechange(w,target) = 1;
                end
            end

        end
    end

    if PH == 0
        break;
    end




    
   
    %%  更新判据
    pp = 0;
    oldpanju = panju;
    oldfuzhuindex = fuzhuindex;
    oldfuzhuptime = fuzhuptime;

    oldfuzhuweapon = fuzhuweapon;
    oldfuzhutarget = fuzhutarget;
    panju = [];
    fuzhuindex = [];
    fuzhuptime = [];
    fuzhuweapon = [];
    fuzhutarget = [];


    % 排序,递增的从最大的开始，递减的也从最大值处开始
    thisind = 0;
    for mubiao = 1:T
        for wuqi  = 1:W
            thisind = thisind + 1;
            if PH(wuqi,mubiao)
                originpp = pp+1;
                if timechange(wuqi,mubiao) == 0 % 没改变的,
                    thisremains = find(oldfuzhuindex==thisind);
                    pp = pp + length(thisremains);
                    copys = [originpp:pp];
                    panju(copys,2) = oldpanju(thisremains,2);
                    fuzhuindex(copys) = oldfuzhuindex(thisremains);
                    fuzhuptime(copys) = oldfuzhuptime(thisremains);

                    fuzhuweapon(copys) = oldfuzhuweapon(thisremains);
                    fuzhutarget(copys) = oldfuzhutarget(thisremains);

                    panju(copys,1) = tempV(1,mubiao);
                else

                    thisdeta = para.deta(wuqi,1);
                    thisTE = TE(wuqi,mubiao);
                    thisTF = TF{wuqi,mubiao};
                    thisLEN = LEN{wuqi,mubiao};
                    thisTM = thisTF + thisTE;
                    thisTMend = thisTM + thisLEN;
                    omaxtime = origin_maxtime(wuqi,mubiao);


                   %% 计算每个匹配对的分配次数numoftt
                    
                    fenbian2 = min(para.N(wuqi,1) - N(wuqi,1), para.lk(1,mubiao) - lk(1,mubiao));
                    

                    thisPtimes = [];
                    thisPs = [];
                    thispp = 0; % 当前时间窗的匹配对个数

                    %% 注意 每一个nn一定会取边界，不考虑不同nn之间的影响——方便计算，所以计算panju3的时候只需要计算本nn内的变化就行了
                    
                    for nn = 1:length(thisTF)
                        currenttype = types(wuqi,mubiao);
                        if currenttype == 3
                            % 在左边，递增
                            if thisTMend(nn)<=omaxtime
                                currenttype = 1;
                                % 在右边，递减
                            elseif thisTM(nn)>=omaxtime
                                currenttype = 2;
                            end
                        end
                        % 递增,最大值在最右边
                        if currenttype == 1
                            currentlen = thisLEN(nn);

                            %% 计算每个匹配对的分配次数numoftt
                            fenbian1 = ceil(currentlen/thisdeta);
                            numoftt0 = min(fenbian1,fenbian2);
                            numoftt = 2*numoftt0;
                            buchang = currentlen/(numoftt-1); 

                            for tt = 1:numoftt
                                thispp = thispp + 1;
                                if tt==1%最右
                                    thisPtime = thisTMend(nn);
                              
                                elseif tt == numoftt%最左
                                    thisPtime = thisTM(end-nn+1);

                                else%中间的
                                    thisPtime = thisTMend(nn)-(tt-1)*buchang;
                                end
                                thisPs(thispp,1) = para.P_a(wuqi,mubiao)*(thisPtime-omaxtime)^2 + para.P_c(wuqi,mubiao);
                                thisPtimes(thispp,1) = thisPtime;
                            end

                            % 递减，最大值在最左边
                        elseif currenttype == 2
                            currentlen = thisLEN(nn);

                            %% 计算每个匹配对的分配次数numoftt
                            fenbian1 = ceil(currentlen/thisdeta);
                            numoftt0 = min(fenbian1,fenbian2);
                            numoftt = 2*numoftt0;
                            buchang = currentlen/(numoftt-1); 

                            for tt = 1:numoftt
                                thispp = thispp + 1;
                                if tt==1%最左
                                    thisPtime = thisTM(nn);
                                   
                                elseif tt == numoftt%最右
                                    thisPtime = thisTMend(nn);
                                   
                                else%中间的
                                    thisPtime = thisTM(nn)+(tt-1)*buchang;
                                end
                                thisPs(thispp,1) = para.P_a(wuqi,mubiao)*(thisPtime-omaxtime)^2 + para.P_c(wuqi,mubiao);
                                thisPtimes(thispp,1) = thisPtime;
                                
                            end

                        else
                            %% 中间 注意不一定对称了！！ 先把右边的全计算完，再算左边的，跟main1顺序不一样
                            %% 先按照规定的步长划分完毕，若由于最大值点位置导致少于规定次数，选择p更大的位置左/右边界
                           
                            %% 计算每个匹配对的分配次数numoftt
                            currentlen = thisLEN(nn);
                            fenbian1 = ceil(currentlen/thisdeta);
                            numoftt0 = min(fenbian1,fenbian2);
                            numoftt = 2*numoftt0;
                            buchang = currentlen/(numoftt-1);

                            rightlen = thisTMend(nn) - omaxtime;
                            leftlen = omaxtime - thisTM(nn);  

                            rightnum = floor(rightlen/buchang);
                            leftnum = floor(leftlen/buchang);
                             
                            for tt = 1:numoftt
                                thispp = thispp + 1;
                                if tt==1 %中间
                                    thisPtime = omaxtime;
                                % 递减部分
                                elseif tt <= 1 + rightnum
                                    thisPtime = omaxtime+(tt-1)*buchang;
                                    % 递增部分
                                elseif tt <= 1 + rightnum + leftnum
                                    thisPtime = omaxtime-(tt-rightnum - 1)*buchang;
                                
                                elseif tt == numoftt
                                    % 左边长，选右边
                                    if rightlen<leftlen
                                        thisPtime = thisTMend(nn);
                                    % 右边长，选左边
                                    elseif rightlen>leftlen
                                        thisPtime = thisTM(nn);
                                    end
                                end

                                thisPs(thispp,1) = para.P_a(wuqi,mubiao)*(thisPtime-omaxtime)^2 + para.P_c(wuqi,mubiao);
                                thisPtimes(thispp,1) = thisPtime;

                            end
                        end
                    end
                    pp = pp + thispp;
                    copys = [originpp:pp];
                    


                    fuzhuindex(copys) = (mubiao-1)*W + wuqi;
                    fuzhuptime(copys) = thisPtimes;

                    fuzhuweapon(copys) = wuqi;
                    fuzhutarget(copys) = mubiao; 


                    % 1 2、该匹配对当前的V*Pmax
                    panju(copys,1) = tempV(1,mubiao);
                    panju(copys,2) = thisPs;
                end
            end
        end
    end



   numofpair = size(panju,1);
    affect = zeros(numofpair,1);
    huxiang = zeros(numofpair,numofpair);
    % 计算panju5
    % 每一组计算的affect肯定是互不重合的
    for wuqi = 1:W
        inds1 = find(fuzhuweapon == wuqi);
        if ~isempty(inds1)
            thisdeta = para.deta(wuqi,1);

            thistimes = fuzhuptime(inds1);

            diffs = abs(thistimes' - thistimes);
            affect1 = diffs <= thisdeta; % 在inds元素对应的矩阵中的距离小于deta的,小于则为1
            affect2 = sum(affect1,2) -1; % 每行求和，为inds中每个元素的距离小于deta的数目,注意去掉自身
            huxiang(inds1,inds1) = affect1;
            affect(inds1) = affect2;
        end

%         for ii = 1:length(inds1)-1
%             pp = inds1(ii);
%             thistime = fuzhuptime(pp);
%             for jj = ii+1 : length(inds1)
%                 pp2 = inds1(jj);
%                 comparetime = fuzhuptime(pp2);
%                 if abs(thistime - comparetime) <= thisdeta % 注意，必须有=才能把同一匹配对的相互影响事件求出来
%                     huxiang(pp,pp2) = 1;
%                     huxiang(pp2,pp) = 1;
%                     affect(pp) = affect(pp) + 1;
%                     affect(pp2) = affect(pp2) + 1;
%                 end
%             end
%         end
    end

    newhuxiang = zeros(numofpair,numofpair);
    for mubiao = 1:T
        inds1 = find(fuzhutarget == mubiao);
        if ~isempty(inds1)
            weapons = fuzhuweapon(inds1);
            thistimes_ft = fuzhuptime(inds1); % 1*n
            te = TE(weapons, mubiao)';
            thistimes_st = thistimes_ft - te;

            thisnum = length(inds1);

            FT = repmat(thistimes_ft,thisnum,1);
            chazhi = FT - thistimes_st'; % 行是st，列是ft，n*n

            chengji =  chazhi.* chazhi';

            affect1 = chengji > 0; % 在inds元素对应的矩阵中的

            newhuxiang(inds1,inds1) = affect1;
            affect2 = sum(affect1,2) -1; % 每行求和，

            affect(inds1) = affect(inds1) + affect2;
        end
%         for ii = 1:length(inds1)-1
%             pp = inds1(ii);
%             aft = fuzhuptime(pp);
%             aweapon = fuzhuweapon(pp);
%             ast = aft - TE(aweapon, mubiao);
%             for jj = ii+1 : length(inds1)
%                 pp2 = inds1(jj);
%                 % 如果已经计算过互相影响，就不要重复计算了
%                 if huxiang(pp,pp2) == 1
%                     continue;
%                 end
%                 bweapon = fuzhuweapon(pp2);
%                 bft = fuzhuptime(pp2);
%                 bst = bft - TE(bweapon, target);
%                 if (bft-ast)*(aft-bst) >0
%                     affect(pp) = affect(pp) + 1;
%                     affect(pp2) = affect(pp2) + 1;
%                 end
%             end
%         end
    end


    calsum = huxiang + newhuxiang;
    chongfu = calsum >= 2; % 资源相影响且任务相影响的事件,需要删除
    delenum = sum(chongfu,2) -1; % 计算每一行资源相影响且任务相影响的事件的数目
    affect = affect-delenum;

    panju(:,3) = affect;




    %     TM = cell(W, T);
%     for j = 1:T
%         for i = 1:W
%             TM{i,j} = TF{i,j}+TE(i,j);
%         end
%     end
%     drawGanttChart(TF, LEN, TM, W, T, 160, times)
    times = times + 1;
    

end


% sol = [mPosition
%     mTF
%     mTM];

mP = roundn(mP, -2);
Fitness = CalFitness(mPosition, mP, para);

end


function drawGanttChart(TF, LEN, TM,W,T,Dmax,times)
c1 = [0 0.4470 0.7410]; % 深蓝

c4 = [0 1 0];% 绿
c5 = [0.4660 0.6740 0.1880];% 浅绿
c6 = [0.3010 0.7450 0.9330]; % 蓝
c7 = [0.6350 0.0780 0.1840]; %红
c8 = [0 0 0];% black



yfig = figure('Visible', 'on');
% 绘制甘特图
events_label = {}; % w1w2w3w4 w1w2w3w4
totalevents = W*T;
% 画出坐标系
for e = 1:totalevents
    weapon = mod((e-1),W)+1;
    target = floor((e-1)/W)+1;
    events_label{e} = ['r',num2str(weapon),' to t',num2str(target)];
end
set(gca,'yticklabel',events_label);
set(gca,'ytick',1:1:totalevents);
set(gca,'xtick',0:10:Dmax);
if totalevents>=100
    set(gca,'yticklabel',events_label,'Fontsize',6);
end

for i = 1: W
    for j = 1:T
        index = (j-1)*W + i;
        for n = 1:length(TF{i,j})
            rectangle('Position', [TF{i,j}(n), index, LEN{i,j}(n), 0.4], 'FaceColor', c4);
            rectangle('Position', [TM{i,j}(n), index-0.4, LEN{i,j}(n), 0.4], 'FaceColor', c5);
        end
    end
end




set(gcf,'Position',get(0,'Screensize')); %将图像全屏显示


xlim([0, Dmax]);
ylim([0, W*T + 0.5]);
xlabel('时间(s)','FontSize',16);
ylabel('可行匹配对','FontSize',16);
title('可行匹配对及对应可行时间窗','FontSize',16);
grid on;
hold on;

%% 保存图片
% name1 =  ['C:\Users\lenovo\Desktop\时间窗约束\codes\results\step',num2str(times),'.png'];
% print(yfig,name1,'-dpng','-r300');         % 指定保存路径
end

