function [D, Dfits1] = calD(D, Dfits1, pop,insnum)
% 行为问题个数，列为个体个数
popfits1 = [pop.Cost1];
popquanzhi = [pop.quanzhi]; % 行为问题维度，列为个体个数

Dfits1 = [Dfits1, popfits1];
D = [D, popquanzhi];


% 一轮更新
paiming = zeros(size(Dfits1));%从大到小 1...100
deles = [];
% 遍历每一行
for aa = 1:size(Dfits1,1)
    thishang = Dfits1(aa,:);
    thisrank = 1;
    while sum(thishang)~=-500*length(thishang)
        thismax = max(thishang);
        maxinds = find(thishang == thismax);
        paiming(aa,maxinds) = thisrank;
        thisrank = thisrank + length(maxinds);
        thishang(maxinds) = -500;
    end
end
repaiming = size(Dfits1,2)+ 1- paiming; % 逆序，从小到大是1.。。100
% 删除排序不为max的个体。遍历每一列
maxvalue = size(Dfits1,2);  % 注意每行最大值一定是算法个数！！因为是从8开始倒数的！
for dd = 1:maxvalue
    if max(repaiming(:,dd))<maxvalue
        deles = [deles dd];
    end
end

repaiming(:,deles) = [];
Dfits1(:,deles) = [];
D(:,deles) = [];


% 二轮更新
% 计算每个算例最大值
leftind = [];
for ll = 1: insnum
    % 算例对应的这一行
    thisinsset = repaiming(ll,:);
    maxv = max(thisinsset);
    thisalgset = find(thisinsset == maxv);% 找到取最大rank的算法索引,作为候选算法集合

    % 跟main中不一样，这里把所有算例都考虑，取rank=max的算法集合中最优的算法，所以是取列，main中是取行
    thisDfits1 = Dfits1(:,thisalgset);
    thiscost = calCost3(thisDfits1);
    [~,ind] = max(thiscost);
    leftind(ll) = ind;
end
leftind2 = unique(leftind);
Dfits1 = Dfits1(:,leftind2);
D = D(:,leftind2);
