function [convergeiter, convergefit, popquanzhi,popfits] = shade(para,can,zongpara,maxvalues)
%% 考虑时刻版本 nvar nvar2
%% Initialization
empty_individual.quanzhi = [];
empty_individual.Cost1 = [];

empty_individual.Cost = [];
convergefit = zeros(1,50);
convergeiter = zeros(1,50);

nPop = zongpara.nPop;


%% shade
pop = repmat(empty_individual, nPop, 1);

%% 1、初始化
for i = 1:nPop
    this1 = -10 + 20*rand(1,zongpara.nvar1); % [-10, 10]
    this2 = -1 + 2*rand(1,zongpara.nvar2); % [-1, 1]
    c = roundn([this1, this2], -3);
    pop(i).quanzhi = c';
    pop(i).Cost1 = CalFitnessAll(pop(i).quanzhi, para,can,zongpara,maxvalues);
end
pop = calCost(pop);

Costs = [pop.Cost];
[bestvalue, bestind] = max(Costs);
fit = bestvalue;
convergefit(1) = fit;
convergeiter(1) = 1;

%% Main Loop
it = zongpara.nPop;
iter = 1;


Archive    = [];

%% 修改
H = 5;
rar = 2;
Asize = nPop*rar;
MCR = zeros(H, 1) + 0.5;
MF  = zeros(H, 1) + 0.5;
k   = 1;


evaluation = zongpara.evaluation;
bubianflag = 1;
flag = 1;
D = [];

while it <= evaluation

    %% 2、SHADE优化权重
    
    [pop, Archive, MCR, MF, k] = operatorT(pop, Archive, MCR, MF, k, Asize,nPop,para,can,zongpara,maxvalues);
    it = it + nPop;
    iter = iter + 1;

    if iter == 2
        [D, Dfits1] = calD0(pop,zongpara.insnum);
    else
        Dold = D;
        [D, Dfits1] = calD(D, Dfits1, pop,zongpara.insnum);
        flag = same(D, Dold);% 1是不变 0 是变

        if flag == 1
            bubianflag = bubianflag + 1;%
        else
            bubianflag = 1;
        end

        if bubianflag > 100
            Costs = [pop.Cost];
            [bestvalue, bestind] = max(Costs);
            fit = bestvalue;
            convergefit(cv+1) = fit;
            convergeiter(cv+1) = iter;
            break;
        end
    end



    if mod(iter,10) == 0
        Costs = [pop.Cost];
        [bestvalue, bestind] = max(Costs);
        fit = bestvalue;
        cv = iter/10+1;
        convergefit(cv) = fit;
        convergeiter(cv) = iter;

    end
end


%% 最优值更新

popfits = Dfits1;
popquanzhi = roundn(D,-3);

end



