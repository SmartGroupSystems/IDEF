function [para,maxvalue] = caseGenerator(type)
% 包含max的计算！！


% 1、规模参数： W T
% 2、目标函数相关属性参数： P V
% 3、资源并行能力约束：L 资源同一时刻最多执行的任务数目
% 4、资源能力上限约束：N 弹药量
% 5、可执行时间窗约束：Tfind_len  TM
% 6、资源准备时间约束 delta
% 7、策略约束 nk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 总作战时长Dmax = 10min = 600s; 只考虑一个资源对一个目标只有一个时间窗的情形
D0 = 0;
Dmax = 160;  %% maxTF=5*10=50, maxTE=50*4=200, maxT=50*(4+1)=250
pmin = 0.2;
pmax = 0.8;
% 1、规模参数： 9个组合
TFrange = [2, 8]; % TF/deta
TFfenjie = 5;
Nmax = 1.5;
TErange = [0.2,3]; % TE/TF
TEfenjie = 1;
lkmax = 1.5;
vmin = 10;
vmax = 1000;  % 最后转换成0.01-1之间！
pmaxl = 0.4;
pmaxu = 0.8;
pminl = 0.2;
pminu = 0.6;

cy2 = mod(type-1,2)+1;
cy11 = mod(type-1,4)+1; % 1234
cy1 = 1;
if cy11>2
    cy1 = 2;
end
yst11 = mod(type-1,8)+1; % 12345678
yst = 1;
if yst11>4
    yst = 2;
end

ysw11 = mod(type-1,16)+1; % 1-8 9-16
ysw = 1;
if ysw11>8
    ysw = 2;
end

t11 = mod(type-1,32)+1;
t = 1;
if t11>16
    t = 2;
end

w = 1;
if type>32
    w = 2;
end



if w == 1
    W = randi([3,5]);
elseif w == 2
    W = randi([6,10]);
end
if t == 1
    T = randi([3,5]);
elseif t == 2
    T = randi([6,10]);
end
%% 准备时间
deta = randi([2,5],[W,1]);
deta_temp = repmat(deta,1,T);


if ysw == 1 % 松约束  两个都松
    %% 1、可开始执行时间窗长度：Tfind_len
    % Tfind_len-2种
    [Tfind_len, as] = calTfind(deta_temp, ysw, TFrange, W, T);
    N = calN(ysw, Nmax, W, T);

elseif ysw == 2 %% 紧约束,至少一个紧


    yss = ones(1,2) + 1; % 1是松，2是紧
    rr = rand();
    if rr<=0.333
        % TF松N紧
        yss(1) = 1;
    elseif 0.333<rr && rr<=0.666
        % TF紧N松
        yss(2) = 1;
    end% 其他情况就是两个都是紧张


    [Tfind_len, as] = calTfind(deta_temp, yss(1), TFrange, W, T);
    N = calN(yss(2), Nmax, W, T);
end




if yst == 1 % 松约束  两个都松
    %% 3、执行时长 Texe;   +  结束时间窗Tmeet
    %  初始Texe-2种：
    [Texe_len, cs] = calTexe(Tfind_len, yst, TErange,W,T);
    %% 4、任务占用资源上限
    lk = callk(yst, lkmax, W, T);

elseif yst == 2  %% 紧约束,至少一个紧
    yss = ones(1,2) + 1; % 1是松，2是紧
    rr = rand();
    if rr<=0.333
        % TE松l紧
        yss(1) = 1;
    elseif 0.333<rr && rr<=0.666
        % TE紧l松
        yss(2) = 1;
    end% 其他情况就是两个都是紧张

    [Texe_len, cs] = calTexe(Tfind_len, yss(1), TErange,W,T);
    lk = callk(yss(2), lkmax, W, T);
end





% 强耦合
% 计算可行执行时间窗长度集合
T_len = (cs+1).*Tfind_len;
T_len_temp = T_len(:);

[T_len_temp, shunxu] = sort(T_len_temp,'descend');

Tfind_stp = zeros(W,T)+Dmax+500;
Tmeet_stp = zeros(W,T)+Dmax+500;

% 找到最长的时间窗
mubiao = floor((shunxu(1)-1)/W) + 1;
wuqi = shunxu(1) - (mubiao-1)*W;
Tfind_stp(wuqi,mubiao) = roundn(D0+(Dmax-D0)*rand(),-2);
Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
while Tmeet_stp(wuqi,mubiao) + Tfind_len(wuqi,mubiao) > Dmax
    Tfind_stp(wuqi,mubiao) = roundn(D0+(Dmax-D0)*rand(),-2);
    Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
end
maxlen = T_len_temp(1);
stp = Tfind_stp(wuqi,mubiao);
etp = roundn(Tmeet_stp(wuqi,mubiao) + Tfind_len(wuqi,mubiao),-2);


for ss = 2:length(shunxu)
    % 全都在最大时间窗范围生成
    mubiao = floor((shunxu(ss)-1)/W) + 1;
    wuqi = shunxu(ss) - (mubiao-1)*W;
    if T_len_temp(ss) == maxlen
        Tfind_stp(wuqi,mubiao) = stp;
        Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao), -2);
    else
        Tfind_stp(wuqi,mubiao) = roundn(stp+(etp-stp)*rand(),-2);
        Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
        while Tmeet_stp(wuqi,mubiao) + Tfind_len(wuqi,mubiao) > Dmax
            Tfind_stp(wuqi,mubiao) = roundn(stp+(etp-stp)*rand(),-2);
            Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
        end
    end

end
Tmeet_len = Tfind_len;



%% 匹配对之间的差异度
% 差异大的
if cy1 == 1

    V= randi([vmin,vmax],[1,T])/1000;
    x = find(V<=0.25*vmax/1000);
    y = find(V>=0.75*vmax/1000);


    while isempty(x)== true || isempty(y)== true
        %
        %                                     disp(isempty(x))
        %                                     disp(isempty(y))

        V= randi([vmin,vmax],[1,T])/1000;

        x = find(V<=0.25*vmax/1000);
        y = find(V>=0.75*vmax/1000);
    end


    PH = pmaxl + (pmaxu-pmaxl)*rand([W,T]);
    shang = (pmaxu+pmaxl)/2+0.1;
    xia = (pmaxu+pmaxl)/2-0.1;
    x = find(PH<=xia);
    y = find(PH>=shang);

    while isempty(x)== true|| isempty(y)== true
        PH = pmaxl + (pmaxu-pmaxl)*rand([W,T]);
        shang = (pmaxu+pmaxl)/2+0.1;
        xia = (pmaxu+pmaxl)/2-0.1;
        x = find(PH<=xia);
        y = find(PH>=shang);
    end


    % 差异小的
elseif cy1 == 2
    V = zeros(1,T);
    for vv = 1: T
        V(1,vv) = randi([0.25*vmax,0.75*vmax])/1000;
    end



    shang = (pmaxu+pmaxl)/2+0.1;
    xia = (pmaxu+pmaxl)/2-0.1;
    PH = xia + (shang-xia)*rand([W,T]);

end



%% 匹配对在不同时刻的差异
% 差异大的
if cy2 == 1

    xiajie = (pmaxu-pminl)/2;
    shangjie = (pmaxu-pminl);

    pdelta =  xiajie + (shangjie-xiajie)*rand([W,T]);

    PL = roundn(PH - pdelta,-2);

    for x = 1:W
        for y = 1:T
            if PL(x,y) <  pmin
                PL(x,y) = pmin;
            end
        end
    end


    % 差异小的
elseif cy2 == 2
    xiajie = (pmaxu-pminu)/2;
    shangjie = (pmaxu-pminl)/2;

    pdelta =  xiajie + (shangjie-xiajie)*rand([W,T]);

    PL = roundn(PH - pdelta,-2);

    for x = 1:W
        for y = 1:T
            if PL(x,y) <  pmin
                PL(x,y) = pmin;
            end
        end
    end
end



P_type = randi([1,3],[W,T]);




%% 4、计算ss概率曲线
P_a = ones(W,T);
P_c = ones(W,T);
% 构造方程组
% 以最高点为坐标原点，最低点为用来计算的点
for ii = 1:W
    for jj = 1:T
        % 设置以0为最高点的一元二次抛物线，递增取坐标轴左侧，递减取坐标轴右侧
        x1 = 0;
        y1 = PH(ii,jj);
        % 递增/递减
        if P_type(ii,jj) == 1 || P_type(ii,jj) == 2
            x2 = Tfind_len(ii,jj); % 长度
        elseif P_type(ii,jj) == 3
            x2 = roundn(Tfind_len(ii,jj)/2,-2); % 长度
        end


        y2 = PL(ii,jj);

        A = [x1^2, 1; x2^2, 1];
        jieju = [y1; y2];

        % 解方程组，得到系数
        coefficients = A \ jieju;

        % 提取系数
        P_a(ii,jj) = coefficients(1);
        P_c(ii,jj) = coefficients(2);

    end
end

para = struct('W',W,'T',T,'V',V,'deta',deta,...
    'TF',Tfind_stp,'LEN',Tfind_len, 'TE', Texe_len,...
    'TM',Tmeet_stp,...
    'PL',PL,'PH',PH,'P_a',P_a,'P_c',P_c,'P_type',P_type,'N',N,'lk',lk);



%% Step1计算资源 对任务 的分配次数上限为
S = zeros(W, T);
for i = 1:W
    for j = 1:T
        a = ceil(Tfind_len(i,j)/deta(i,1));
        b = ceil(Tfind_len(i,j)/Texe_len(i,j));
        temps1 = min(a,b);
        temps2 = min(temps1, N(i,1));
        S(i,j) = min(temps2, lk(1,j));
    end
end

mubiaohe = sum(S,1);% 每列求和的行向量，得到每个任务的总和
totalni = sum(N);

maxvalue = 0;
for j = 1:T
    %% step2.1每个匹配对取最大概率，并复制Sikmax次，加入候选概率集合A
    A = [];
    for i = 1:W
        for s = 1:S(i,j)
            A = [A, PH(i,j)];
        end
    end
    %% Step2.2 每个任务的最大分配次数为
    Skmax = min(mubiaohe(j), lk(1,j));
    Skmax = min(Skmax, totalni);
    %% Step2.3 将A中概率从大到小排列，从A中取前 个概率，构成集合 ，将这些概率作为执行该任务的概率值
    B = sort(A,'descend');
    P = B(1:Skmax);
    ss = prod((1-P));
    maxvalue = maxvalue + V(1,j)*(1-ss);
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






function [Tfind_len,r] = calTfind(deta_temp, tf, TFrange,W, T)
%% 对每个武器，T个匹配对在TFrange内随机生成,均值是a(tf)
min_value = TFrange(1);
max_value = TFrange(2);
maxTimes = 3*T;
if tf == 1
    mean_value = randi([5, max_value],[W,1]);
else
    mean_value = randi([min_value, 4],[W,1]);
end

r = mean_value.*ones(W,T);
for i = 1:W
    % 指定随机整数的范围
    times = 0;
    while times <= maxTimes
        inds = randi([1,T],[1,2]);
        while inds(1) == inds(2)
            inds = randi([1,T],[1,2]);
        end

        ii1 = inds(1);
        jj1 = inds(2);
        times = times + 1;
        if r(i, ii1)>min_value && r(i,ii1)<max_value &&...
                r(i,jj1)>min_value && r(i,jj1)<max_value
            r(i,ii1) = r(i,ii1) - 1;
            r(i,jj1) = r(i,jj1) + 1;
        end
    end

end
Tfind_len = roundn(r.*deta_temp,-2);

end



function N = calN(nn, Nmax, W, T)
maxTimes = W;
% 指定随机整数的范围
min_value = 1;
max_value = ceil(Nmax*T);

if nn == 1
    mean_value = randi([T, max_value]);
else

    if T == 3
        mean_value = 2;
    else
        mean_value = randi([min_value+1, T-1]);
    end
end

r = ceil(mean_value.*ones(W,1));



times = 0;
while times <= maxTimes
    inds = randi([1,W],[1,2]);
    while inds(1) == inds(2)
        inds = randi([1,W],[1,2]);
    end

    ii1 = inds(1);
    jj1 = inds(2);
    times = times + 1;
    if r(ii1)>min_value && r(ii1)<max_value &&...
            r(jj1)>min_value && r(jj1)<max_value
        r(ii1) = r(ii1) - 1;
        r(jj1) = r(jj1) + 1;
    end
end
N = r;

end







function [Texe_len, r] = calTexe(Tfind_len, te, TErange,W,T)
%% 对每个任务，W个匹配对在TErange内随机生成,均值是c(te)
maxTimes = 3*W;
min_value = TErange(1);
max_value = TErange(2);


if te == 1
    mean_value = round((max_value - 1) * rand(1,T) + 1, 1);
else
    mean_value = round((1-0.1 - (min_value+0.1))*rand(1,T) + (min_value+0.1), 1);
end

r = mean_value.*ones(W,T);
for i = 1:T
    times = 0;
    while times <= maxTimes
        inds = randi([1,W],[1,2]);
        while inds(1) == inds(2)
            inds = randi([1,W],[1,2]);
        end

        ii = inds(1);
        jj = inds(2);
        times = times + 1;
        if r(ii,i)>min_value && r(ii,i)<max_value &&...
                r(jj,i)>min_value && r(jj,i)<max_value
            r(ii,i) = r(ii,i) - 0.1;
            r(jj,i) = r(jj,i) + 0.1;
        end
    end

end
Texe_len = roundn(r.*Tfind_len, -2);
end



function lk = callk(ll, lkmax, W, T)
maxTimes = T;

% 指定随机整数的范围
min_value = 1;
max_value = ceil(lkmax*W);


if ll == 1
    mean_value = randi([W, max_value]);
else
    if W == 3
        mean_value = 2;
    else
        mean_value = randi([min_value+1, W-1]);
    end

end

r = ceil(mean_value.*ones(1,T));

times = 0;
while times <= maxTimes
    inds = randi([1,T],[1,2]);
    while inds(1) == inds(2)
        inds = randi([1,T],[1,2]);
    end

    ii1 = inds(1);
    jj1 = inds(2);
    times = times + 1;
    if r(ii1)>min_value && r(ii1)<max_value &&...
            r(jj1)>min_value && r(jj1)<max_value
        r(ii1) = r(ii1) - 1;
        r(jj1) = r(jj1) + 1;
    end
end
lk = r;

end








