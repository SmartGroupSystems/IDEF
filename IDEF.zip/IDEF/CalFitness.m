function [Fitness] = CalFitness(mPosition, mP, para)
%% 目标函数值计算
%% 已成功打击威胁值最大 max

p_fail = ones(1,para.T);
for i = 1:length(mPosition)
    ind_target = floor((mPosition(i)-1)/para.W) + 1;
%     ind_weapon = mPosition(i) - (ind_target-1)*para.W;
    p_fail(ind_target) = p_fail(ind_target)*(1-mP(i));
end

Fitness = roundn(sum(para.V.*(1 - p_fail)),-3); % 求和


end