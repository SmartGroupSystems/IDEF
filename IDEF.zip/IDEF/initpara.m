function [para, can, zongpara, maxvalues] =  initpara(insset)
% nvar是判据个数(网络输入维度)，nvar1是中心点向量总维度，nvar2是神经元输出权值维度（就是神经元个数）
nvar = 3; 
nvar1 = 3*nvar;
nvar2 = 3;
spread = 1;
nPop = 10*(nvar1+nvar2);
evaluation = nPop*500;
insnum = length(insset);
maxvalues =  readmatrix('C:\Users\lenovo\Desktop\HH\results\\maxvalue.xlsx');
maxvalues = maxvalues(1:64);
for ni = 1:insnum
    ins = insset(ni);
    eval(['load C:\Users\lenovo\Desktop\HH\instance2025\\instance',num2str(ins)]);
    para(ni) = struct('W',W,'T',T,'V',V,'deta',deta,...
        'TF',Tfind_stp,'LEN',Tfind_len, 'TE', Texe_len,...
        'TM',Tmeet_stp,...
        'PL',PL,'PH',PH,'P_a',P_a,'P_c',P_c,'P_type',P_type,'N',N,'lk',lk);

    %% 计算所有匹配对的判据
    pp = 0;
    panju = [];
    fuzhuindex = [];% index
    fuzhuptime = [];
    fuzhuweapon = [];
    fuzhutarget = [];
    % noTF=0, flagTF = 0  ——表示panju4=0
    % 排序,递增的从最大的开始，递减的也从最大值处开始
    for target = 1:T
        for weapon = 1:W


            thisLEN = para(ni).LEN(weapon,target);
            thisdeta = deta(weapon,1);

            %% 计算每个匹配对的分配次数numoftt
            fenbian1 = ceil(thisLEN/thisdeta);
            fenbian2 = min(N(weapon,1), lk(1,target));
            numoftt = min(fenbian1,fenbian2);
            numoftt = 2*numoftt;

            % 递增,最大值在最右边

            if P_type(weapon,target) == 1
                buchang = thisLEN/(numoftt-1);
                for tt = 1:numoftt
                    pp = pp + 1;
                    if tt == 1
                        thisP = PH(weapon,target); % 最大值
                        thisPtime = para(ni).TM(weapon,target)+thisLEN; %origin_maxtime
                    elseif tt == numoftt
                        thisP = PL(weapon,target); % 最小值
                        thisPtime = para(ni).TM(weapon,target);
                    else
                        thisPtime = para(ni).TM(weapon,target)+thisLEN- (tt-1)*buchang;
                        thisP = P_a(weapon,target)*((tt-1)*buchang)^2 + P_c(weapon,target);
                    end
                    fuzhuindex(pp) = (target-1)*W + weapon;
                    fuzhuptime(pp) = thisPtime;
                    fuzhuweapon(pp) = weapon;
                    fuzhutarget(pp) = target;

                    % 1 2、该匹配对当前的V*Pmax
                    panju(pp,1) = V(1,target);
                    panju(pp,2) = thisP;

                end

            elseif P_type(weapon,target) == 2 % 递减，最大值在最左边
                buchang = thisLEN/(numoftt-1);
                for tt = 1:numoftt
                    pp = pp + 1;
                    if tt == 1
                        thisP = PH(weapon,target); % 最大值
                        thisPtime = para(ni).TM(weapon,target);
                    elseif tt == numoftt
                        thisP = PL(weapon,target); % 最小值
                        thisPtime = para(ni).TM(weapon,target)+thisLEN;
                    else
                        thisPtime = para(ni).TM(weapon,target) + (tt-1)*buchang;
                        thisP = P_a(weapon,target)*((tt-1)*buchang)^2 + P_c(weapon,target);
                    end
                    fuzhuindex(pp) = (target-1)*W + weapon;
                    fuzhuptime(pp) = thisPtime;
                    fuzhuweapon(pp) = weapon;
                    fuzhutarget(pp) = target;

                    % 1 2、该匹配对当前的V*Pmax
                    panju(pp,1) = V(1,target);
                    panju(pp,2) = thisP;

                end
                % 在中间 注意，由于最开始一定是对称的，所以遵循 右一个，做一个，但是后面的TT中 是先把右边的全计算完，再算左边的
            else
                % 偶数个，增加1
                if mod(numoftt, 2) == 0
                    numoftt = numoftt + 1;
                end

                buchang = thisLEN/(numoftt-1);
                for tt = 1:numoftt
                    pp = pp + 1;
                    maxptime = roundn(para(ni).TM(weapon,target)+para(ni).LEN(weapon,target)/2 ,-2);
                    if tt == 1
                        thisP = PH(weapon,target); % 最大值
                        thisPtime = maxptime;
                    elseif tt == numoftt-1 % 两个边界！先右  注意对称的p是一样的
                        thisP = PL(weapon,target); % 最小值
                        thisPtime = para(ni).TM(weapon,target)+thisLEN;
                    elseif tt == numoftt  % 两个边界！后左  注意对称的p是一样的
                        thisP = PL(weapon,target); % 最小值
                        thisPtime = para(ni).TM(weapon,target);
                    else
                        if mod(tt,2) == 0 % 偶数 往右
                            thisPtime = maxptime + tt/2*buchang;
                            thisP = P_a(weapon,target)*(tt/2*buchang)^2 + P_c(weapon,target);
                        else % 奇数， 往左
                            thisPtime = maxptime - (tt-1)/2*buchang;
                            thisP = P_a(weapon,target)*((tt-1)/2*buchang)^2 + P_c(weapon,target);
                        end

                    end
                    fuzhuindex(pp) = (target-1)*W + weapon;
                    fuzhuptime(pp) = thisPtime;
                    fuzhuweapon(pp) = weapon;
                    fuzhutarget(pp) = target;

                    % 1 2、该匹配对当前的V*Pmax
                    panju(pp,1) = V(1,target);
                    panju(pp,2) = thisP;

                end


            end
        end
    end

    numofpair = size(panju,1);
    affect = zeros(numofpair,1);
    huxiang = zeros(numofpair,numofpair);
    % 计算panju5
    % 每一组计算的affect肯定是互不重合的
    for wuqi = 1:W
        inds1 = find(fuzhuweapon == wuqi);
        thisdeta = deta(wuqi,1);

        thistimes = fuzhuptime(inds1);

        diffs = abs(thistimes' - thistimes);
        affect1 = diffs <= thisdeta; % 在inds元素对应的矩阵中的距离小于deta的,小于则为1
        affect2 = sum(affect1,2) -1; % 每行求和，为inds中每个元素的距离小于deta的数目,注意去掉自身
        huxiang(inds1,inds1) = affect1;
        affect(inds1) = affect2;

        %         for ii = 1:length(inds1)-1
        %             pp = inds1(ii);
        %             thistime = fuzhuptime(pp);
        %             for jj = ii+1 : length(inds1)
        %                 pp2 = inds1(jj);
        %                 comparetime = fuzhuptime(pp2);
        %                 if abs(thistime - comparetime) <= thisdeta % 注意，必须有=才能把同一匹配对的相互影响事件求出来
        %                     huxiang(pp,pp2) = 1;
        %                     huxiang(pp2,pp) = 1;
        %                     affect(pp) = affect(pp) + 1;
        %                     affect(pp2) = affect(pp2) + 1;
        %                 end
        %             end
        %         end
    end

    newhuxiang = zeros(numofpair,numofpair);
    for mubiao = 1:T
        inds1 = find(fuzhutarget == mubiao);
        weapons = fuzhuweapon(inds1);
        thistimes_ft = fuzhuptime(inds1); % 1*n
        te = para(ni).TE(weapons, mubiao)';
        thistimes_st = thistimes_ft - te;

        thisnum = length(inds1);

        FT = repmat(thistimes_ft,thisnum,1);
        chazhi = FT - thistimes_st'; % 行是st，列是ft，n*n

        chengji =  chazhi.* chazhi';

        affect1 = chengji > 0; % 在inds元素对应的矩阵中的

        newhuxiang(inds1,inds1) = affect1;
        affect2 = sum(affect1,2) -1; % 每行求和，

        affect(inds1) = affect(inds1) + affect2;
        %         for ii = 1:length(inds1)-1
        %             pp = inds1(ii);
        %             aft = fuzhuptime(pp);
        %             aweapon = fuzhuweapon(pp);
        %             ast = aft - TE(aweapon, mubiao);
        %             for jj = ii+1 : length(inds1)
        %                 pp2 = inds1(jj);
        %                 % 如果已经计算过互相影响，就不要重复计算了
        %                 if huxiang(pp,pp2) == 1
        %                     continue;
        %                 end
        %                 bweapon = fuzhuweapon(pp2);
        %                 bft = fuzhuptime(pp2);
        %                 bst = bft - TE(bweapon, target);
        %                 if (bft-ast)*(aft-bst) >0
        %                     affect(pp) = affect(pp) + 1;
        %                     affect(pp2) = affect(pp2) + 1;
        %                 end
        %             end
        %         end
    end


    calsum = huxiang + newhuxiang;
    chongfu = calsum >= 2; % 资源相影响且任务相影响的事件,需要删除
    delenum = sum(chongfu,2) -1; % 计算每一行资源相影响且任务相影响的事件的数目
    affect = affect-delenum;
    panju(:,3) = affect;



    % 1、先把0行确立——初始没有0行
    %2、 更新每列最大值
    maximum = max(panju,[],1);
    % minimum = min(panju,[],1);
    for mm = 1:nvar
        if maximum(mm) == 0
            maximum(mm) = 1;
        end
    end

    %% 归一化判据
    npanju = panju./maximum;

    can(ni) = struct('panju',panju,'npanju',npanju,'fuzhuindex',fuzhuindex,'fuzhuptime',fuzhuptime,...
        'fuzhuweapon',fuzhuweapon,'fuzhutarget',fuzhutarget);

end


zongpara = struct('insnum', insnum,'nvar',nvar,'nvar1',nvar1,'nvar2',nvar2,'spread',spread,...
    'nPop',nPop,'evaluation',evaluation);
