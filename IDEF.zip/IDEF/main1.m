function [popquanzhi,popfits] = main1(times,para,can,zongpara,maxvalues)

[convergeiter, convergefit, popquanzhi,popfits] = shade(para,can,zongpara,maxvalues);




% names6 = ['C:\Users\lenovo\Desktop\HH\results\\GAE9-32-16_convergefit.xlsx'];
% writematrix(convergefit,names6,'Sheet',times,'WriteMode','append');
% 
% 
% names7 = ['C:\Users\lenovo\Desktop\HH\results\\GAE9-32-16_convergeiter.xlsx'];
% writematrix(convergeiter,names7,'Sheet',times,'WriteMode','append');
% 
% names8 = ['C:\Users\lenovo\Desktop\HH\results\\GAE9-32-16_popquanzhi.xlsx'];
% writematrix(popquanzhi,names8,'Sheet',times,'WriteMode','append');
% names9 = ['C:\Users\lenovo\Desktop\HH\results\\GAE9-32-16_popfits.xlsx'];
% writematrix(popfits,names9,'Sheet',times,'WriteMode','append');



end

