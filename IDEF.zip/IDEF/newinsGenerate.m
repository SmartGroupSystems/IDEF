function [para, newlei, maxvalues_Inew] = newinsGenerate(g, num, step)

newlei = [];

% 计算理论分配数
n_float = g.* num;

% 分配整数部分
n_int = floor(n_float);
remainders = n_float - n_int;

% 剩余待分配名额
remaining = num - sum(n_int);

% 按小数部分排序，补充分配
[~, idx] = sort(remainders, 'descend');
n_int(idx(1:remaining)) = n_int(idx(1:remaining)) + 1;


maxvalues_Inew = [];
ni = 1;
for ii = 1:step
    if n_int(ii)>0
        for times = 1:n_int(ii)
            [paranew, maxvalue] = caseGenerator(ii);
            para(ni) = paranew;
            maxvalues_Inew(ni,1) = maxvalue;
            ni = ni+1;
            newlei = [newlei ii];
        end
    end
end

end




