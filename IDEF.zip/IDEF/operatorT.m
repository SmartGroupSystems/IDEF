function [pop, Archive, MCR, MF, k] = operatorT(pop, Archive, MCR, MF, k, Asize,thisnpop,para,can,zongpara,maxvalues)

nvar1 = zongpara.nvar1;
nvar2 = zongpara.nvar2;
totalvar  = nvar1 + nvar2;

CR  = randn(thisnpop,1).*sqrt(0.1) + MCR(randi(end,thisnpop,1));
CR  = repmat(max(0,min(1,CR)),1, totalvar); % npop*(nvar)
F   = min(1,trnd(1,thisnpop,1).*sqrt(0.1) + MF(randi(end,thisnpop,1)));
while any(F<=0)
    F(F<=0) = min(1,trnd(1,sum(F<=0),1).*sqrt(0.1) + MF(randi(end,sum(F<=0),1)));
end
F = repmat(F,1, totalvar);

Site         = rand(size(CR)) < CR;

[~,rank] = sort([pop.Cost],'descend'); 
p = rank(ceil(rand(1,thisnpop).*max(2,rand(1,thisnpop)*0.2*thisnpop))); % 1*nPop
PP = [pop
    Archive];



%% 根据公式获取新解
Offspring = pop;
mPositions = zeros(thisnpop,totalvar);
for n = 1:thisnpop
    if Site(n,:) == 0
        mPositions(n,:) = [pop(n).quanzhi]';
        continue;
    end
    r1 = randi(thisnpop);
    r2 = randi(numel(PP));
    while r2==r1
        r2 = randi(numel(PP));
    end
    % 当前个体x
    xquanzhi = [pop(n).quanzhi]';
    % pbest
    Xpb = [pop(p(n)).quanzhi]';
    % xr1
    Xr1 = [pop(r1).quanzhi]';
    % xr2
    Xr2 = [PP(r2).quanzhi]';


    mPosition = xquanzhi;
    thissite = Site(n,:);
    mPosition(thissite) = xquanzhi(thissite) + ...
        F(thissite).*(Xpb(thissite)-xquanzhi(thissite)+Xr1(thissite)-Xr2(thissite));
    

% 【-10，10】 【-1，1】
    mPosition(mPosition>10) = 10;
    mPosition(mPosition<-10) = -10;
    temp = mPosition(nvar1+1 : end);
    temp(temp<-1) = -1; 
    temp(temp>1) = 1; 
    mPosition(nvar1+1 : end) = temp;
    mPositions(n,:) = mPosition;

    

end
% thisnpop
% mPositions
% Offspring
%% 计算fitness
% Cost1 = zeros(zongpara.insnum,thisnpop);
parfor n = 1:thisnpop
    if Site(n,:) ~= 0
        thispos = [mPositions(n,:)]';
        Offspring(n).quanzhi = roundn(thispos,-3);
        Offspring(n).Cost1  = CalFitnessAll(thispos, para,can,zongpara,maxvalues);
    end
end
Offspring = calCost(Offspring);


%% 获得子代个体的解

% Update the pop and archive
offcost = [Offspring.Cost];
delta   = [pop.Cost] - offcost;

%% A-保存差于新个体的父代（原始父代
replace = delta < 0;

Archive = [Archive
    pop(replace)];
Archive = Archive(randperm(end, min(end,Asize)));



%% 更新参数
if any(replace)
    pop(replace) = Offspring(replace);
    w      = delta(replace)./sum(delta(replace));
    MCR(k) = dot(w,CR(replace,1));
    MF(k)  = dot(w,F(replace,1).^2)./dot(w,F(replace,1));
    k      = mod(k,length(MCR)) + 1;

end

end



