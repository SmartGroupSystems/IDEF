%% F3越小越好 1是后胜，2是前胜 0 是互不支配
function b = DominatesF3(x,y)

b = 0;
if all(x<=y) && any(x<y)
    b = 2;  % x小，说明x主导
elseif all(x>=y) && any(x>y)
    b = 1;
end

end