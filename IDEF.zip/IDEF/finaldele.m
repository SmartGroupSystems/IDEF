clear
clc

THETA_F2_Itotal = readmatrix('C:\Users\lenovo\Desktop\HH\results\\RBFLx2ALL8-8_thetafitstotal.xlsx','Sheet',50);
THETA = readmatrix('C:\Users\lenovo\Desktop\HH\results\\final_theta8-8.xlsx','Sheet',1);
cost = calCost3(THETA_F2_Itotal);
% 对向量进行升序排序，并返回索引
[~, sorted_indices] = sort(cost);
% 提取前 n个最小数的索引
prune_inds = sorted_indices(1:size(THETA, 2) - 64);
THETA(:,prune_inds) = [];
THETA_F2_Itotal(:,prune_inds) = [];
namest = ['C:\Users\lenovo\Desktop\HH\results\\final_theta8-8-.xlsx'];
writematrix(THETA,namest,'Sheet',1,'WriteMode','append');