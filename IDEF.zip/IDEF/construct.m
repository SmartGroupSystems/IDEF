function nfitness = construct(THETA, para, zongpara, can, maxvalue)
% nvar是判据个数(网络输入维度)，nvar1是中心点向量总维度，nvar2是神经元输出权值维度（就是神经元个数）
%% 构造每一个规则在每一个算例上的解

%% 行为问题个数，列为规则个数
fitness = zeros(1, size(THETA, 2));
% 遍历每一个规则
parfor gz = 1: size(THETA, 2)
    quanzhi = THETA(:,gz);
    fitness(gz) = CalFitnessbigTT(quanzhi,para,can,zongpara);

end
nfitness = fitness./maxvalue; %% 归一化