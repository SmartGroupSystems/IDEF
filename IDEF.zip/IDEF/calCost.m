function pop = calCost(pop)
A = [pop.Cost1];
paiming = zeros(size(A));%从大到小 1...100
% 遍历每一行
for aa = 1:size(A,1)
    thishang = A(aa,:);
    thisrank = 1;
    while sum(thishang)~=-500*length(thishang)
        thismax = max(thishang);
        maxinds = find(thishang == thismax);
        paiming(aa,maxinds) = thisrank;
        thisrank = thisrank + length(maxinds);
        thishang(maxinds) = -500;
    end
end
repaiming = size(A,2)+ 1- paiming; % 逆序，从小到大是1.。。100
normpaiming = repaiming./size(A,2);  % 每一列除以最大排序,实现归一化
chengji = A.*normpaiming;
Cost = sum(chengji,1); % 每列求和得到行向量

for bb = 1:size(A,2)
    pop(bb).Cost = Cost(bb);
end


