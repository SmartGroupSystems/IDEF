clear
clc


ins = 65;

D0 = 0;
Dmax = 160;  
pmin = 0.2;
pmax = 0.8;
TFrange = [2, 8]; 
TFfenjie = 5;
Nmax = 1.5;
TErange = [0.2,3]; 
TEfenjie = 1;
lkmax = 1.5;
vmin = 10;
vmax = 1000;  
pmaxl = 0.4;
pmaxu = 0.8;
pminl = 0.2;
pminu = 0.6;
for tt = 1:2
    for w = 1: 2
        if w == 1
            W = randi([3,5]);
        else
            W = randi([6,20]);
        end
        for t = 1:2
            if t == 1
                T = randi([3,5]);
            else
                T = randi([6,20]);
            end

            for ysw = 1:2
                for yst = 1:2
                    for cy1 = 1:2
                        for cy2 = 1:2
                  
                            deta = randi([2,5],[W,1]);

                           
                            deta_temp = repmat(deta,1,T);


                            if ysw == 1 
                           
                                [Tfind_len, as] = calTfind(deta_temp, ysw, TFrange, W, T);
                                N = calN(ysw, Nmax, W, T);

                            elseif ysw == 2 
                                
                                
                                yss = ones(1,2) + 1; 
                                rr = rand();
                                if rr<=0.333
                        
                                    yss(1) = 1;
                                elseif 0.333<rr && rr<=0.666
                                 
                                    yss(2) = 1;
                                end
                                
                                
                                [Tfind_len, as] = calTfind(deta_temp, yss(1), TFrange, W, T);
                                N = calN(yss(2), Nmax, W, T);
                            end




                            if yst == 1 
                                
                                
                                [Texe_len, cs] = calTexe(Tfind_len, yst, TErange,W,T);
                                
                                lk = callk(yst, lkmax, W, T);

                            elseif yst == 2  
                                yss = ones(1,2) + 1; 
                                rr = rand();
                                if rr<=0.333
                                    
                                    yss(1) = 1;
                                elseif 0.333<rr && rr<=0.666
                                
                                    yss(2) = 1;
                                end
                                
                                [Texe_len, cs] = calTexe(Tfind_len, yss(1), TErange,W,T);
                                lk = callk(yss(2), lkmax, W, T);
                            end



                    

               
                            T_len = (cs+1).*Tfind_len;
                            T_len_temp = T_len(:);

                            [T_len_temp, shunxu] = sort(T_len_temp,'descend');

                            Tfind_stp = zeros(W,T)+Dmax+500;
                            Tmeet_stp = zeros(W,T)+Dmax+500;

                       
                            mubiao = floor((shunxu(1)-1)/W) + 1;
                            wuqi = shunxu(1) - (mubiao-1)*W;
                            Tfind_stp(wuqi,mubiao) = roundn(D0+(Dmax-D0)*rand(),-2);
                            Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
                            while Tmeet_stp(wuqi,mubiao) + Tfind_len(wuqi,mubiao) > Dmax
                                Tfind_stp(wuqi,mubiao) = roundn(D0+(Dmax-D0)*rand(),-2);
                                Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
                            end
                            maxlen = T_len_temp(1);
                            stp = Tfind_stp(wuqi,mubiao);
                            etp = roundn(Tmeet_stp(wuqi,mubiao) + Tfind_len(wuqi,mubiao),-2);


                            for ss = 2:length(shunxu)
                                
                                mubiao = floor((shunxu(ss)-1)/W) + 1;
                                wuqi = shunxu(ss) - (mubiao-1)*W;
                                if T_len_temp(ss) == maxlen
                                    Tfind_stp(wuqi,mubiao) = stp;
                                    Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao), -2);
                                else
                                    Tfind_stp(wuqi,mubiao) = roundn(stp+(etp-stp)*rand(),-2);
                                    Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
                                    while Tmeet_stp(wuqi,mubiao) + Tfind_len(wuqi,mubiao) > Dmax
                                        Tfind_stp(wuqi,mubiao) = roundn(stp+(etp-stp)*rand(),-2);
                                        Tmeet_stp(wuqi,mubiao) = roundn(Tfind_stp(wuqi,mubiao) + Texe_len(wuqi,mubiao),-2);
                                    end
                                end

                            end
                            Tmeet_len = Tfind_len;



                         
                            if cy1 == 1

                                V= randi([vmin,vmax],[1,T])/1000;
                                x = find(V<=0.25*vmax/1000);
                                y = find(V>=0.75*vmax/1000);

                                
                                while isempty(x)== true || isempty(y)== true 
                                  
                                    V= randi([vmin,vmax],[1,T])/1000;
                                
                                    x = find(V<=0.25*vmax/1000);
                                    y = find(V>=0.75*vmax/1000);
                                end


                                PH = pmaxl + (pmaxu-pmaxl)*rand([W,T]);
                                shang = (pmaxu+pmaxl)/2+0.1;
                                xia = (pmaxu+pmaxl)/2-0.1;
                                x = find(PH<=xia);
                                y = find(PH>=shang);

                                while isempty(x)== true|| isempty(y)== true
                                    PH = pmaxl + (pmaxu-pmaxl)*rand([W,T]);
                                    shang = (pmaxu+pmaxl)/2+0.1;
                                    xia = (pmaxu+pmaxl)/2-0.1;
                                    x = find(PH<=xia);
                                    y = find(PH>=shang);
                                end
 

                                
                            elseif cy1 == 2
                                V = zeros(1,T);
                                for vv = 1: T
                                    V(1,vv) = randi([0.25*vmax,0.75*vmax])/1000;
                                end
     

                                
                                shang = (pmaxu+pmaxl)/2+0.1;
                                xia = (pmaxu+pmaxl)/2-0.1;
                                PH = xia + (shang-xia)*rand([W,T]);
       
                            end



             
                            if cy2 == 1

                                xiajie = (pmaxu-pminl)/2;
                                shangjie = (pmaxu-pminl);

                                pdelta =  xiajie + (shangjie-xiajie)*rand([W,T]);

                                PL = roundn(PH - pdelta,-2);

                                for x = 1:W
                                    for y = 1:T
                                        if PL(x,y) <  pmin
                                            PL(x,y) = pmin;
                                        end
                                    end
                                end


                               
                            elseif cy2 == 2
                                xiajie = (pmaxu-pminu)/2;
                                shangjie = (pmaxu-pminl)/2;

                                pdelta =  xiajie + (shangjie-xiajie)*rand([W,T]);

                                PL = roundn(PH - pdelta,-2);

                                for x = 1:W
                                    for y = 1:T
                                        if PL(x,y) <  pmin
                                            PL(x,y) = pmin;
                                        end
                                    end
                                end
                            end



                            P_type = randi([1,3],[W,T]);




                            
                            P_a = ones(W,T);
                            P_c = ones(W,T);
                            
                            for ii = 1:W
                                for jj = 1:T
                                    
                                    x1 = 0;
                                    y1 = PH(ii,jj);
                                    
                                    if P_type(ii,jj) == 1 || P_type(ii,jj) == 2
                                        x2 = Tfind_len(ii,jj); 
                                    elseif P_type(ii,jj) == 3
                                        x2 = roundn(Tfind_len(ii,jj)/2,-2); 
                                    end


                                    y2 = PL(ii,jj);

                                    A = [x1^2, 1; x2^2, 1];
                                    jieju = [y1; y2];

                                    
                                    coefficients = A \ jieju;

                                    
                                    P_a(ii,jj) = coefficients(1);
                                    P_c(ii,jj) = coefficients(2);

                                end
                            end

                            events = 1:1:W*T;
                            % 绘制甘特图
                            startTimes1 = Tfind_stp(:);
                            durations1 = Tfind_len(:);
                            startTimes2 = Tmeet_stp(:);
                            durations2 = Tmeet_len(:);
                            drawGanttChart(events, startTimes1, durations1, startTimes2, durations2,W,T,ins,Dmax);


                            name = ['C:\Users\lenovo\Desktop\HH\instanceTESTF\instance',num2str(ins),'.mat'];
                            save(name, 'W','T','V','deta',...
                                'Tfind_stp','Tfind_len', 'Texe_len', 'Tmeet_stp','Tmeet_len',...
                                'PL','PH','P_a','P_c','P_type','N','lk');
                            ins = ins + 1;
                            %                                     end
                        end
                    end
                end
            end
        end
    end
end






function [Tfind_len,r] = calTfind(deta_temp, tf, TFrange,W, T)
min_value = TFrange(1);
max_value = TFrange(2);
maxTimes = 3*T;
if tf == 1
    mean_value = randi([5, max_value],[W,1]);
else
    mean_value = randi([min_value, 4],[W,1]);
end

r = mean_value.*ones(W,T);
for i = 1:W

    times = 0;
    while times <= maxTimes
        inds = randi([1,T],[1,2]);
        while inds(1) == inds(2)
            inds = randi([1,T],[1,2]);
        end

        ii = inds(1);
        jj = inds(2);
        times = times + 1;
        if r(i, ii)>min_value && r(i,ii)<max_value &&...
                r(i,jj)>min_value && r(i,jj)<max_value
            r(i,ii) = r(i,ii) - 1;
            r(i,jj) = r(i,jj) + 1;
        end
    end

end
Tfind_len = roundn(r.*deta_temp,-2);

end



function N = calN(nn, Nmax, W, T)
maxTimes = W;

min_value = 1;
max_value = ceil(Nmax*T);

if nn == 1
    mean_value = randi([T, max_value]);
else
   
    if T == 3
        mean_value = 2;
    else
        mean_value = randi([min_value+1, T-1]);
    end
end

r = ceil(mean_value.*ones(W,1));



times = 0;
while times <= maxTimes
    inds = randi([1,W],[1,2]);
    while inds(1) == inds(2)
        inds = randi([1,W],[1,2]);
    end

    ii = inds(1);
    jj = inds(2);
    times = times + 1;
    if r(ii)>min_value && r(ii)<max_value &&...
            r(jj)>min_value && r(jj)<max_value
        r(ii) = r(ii) - 1;
        r(jj) = r(jj) + 1;
    end
end
N = r;

end







function [Texe_len, r] = calTexe(Tfind_len, te, TErange,W,T)

maxTimes = 3*W;
min_value = TErange(1);
max_value = TErange(2);


if te == 1
    mean_value = round((max_value - 1) * rand(1,T) + 1, 1);
else
    mean_value = round((1-0.1 - (min_value+0.1))*rand(1,T) + (min_value+0.1), 1);
end

r = mean_value.*ones(W,T);
for i = 1:T
    times = 0;
    while times <= maxTimes
        inds = randi([1,W],[1,2]);
        while inds(1) == inds(2)
            inds = randi([1,W],[1,2]);
        end

        ii = inds(1);
        jj = inds(2);
        times = times + 1;
        if r(ii,i)>min_value && r(ii,i)<max_value &&...
                r(jj,i)>min_value && r(jj,i)<max_value
            r(ii,i) = r(ii,i) - 0.1;
            r(jj,i) = r(jj,i) + 0.1;
        end
    end

end
Texe_len = roundn(r.*Tfind_len, -2);
end



function lk = callk(ll, lkmax, W, T)
maxTimes = T;

min_value = 1;
max_value = ceil(lkmax*W);


if ll == 1
    mean_value = randi([W, max_value]);
else
    if W == 3
        mean_value = 2;
    else
        mean_value = randi([min_value+1, W-1]);
    end

end

r = ceil(mean_value.*ones(1,T));

times = 0;
while times <= maxTimes
    inds = randi([1,T],[1,2]);
    while inds(1) == inds(2)
        inds = randi([1,T],[1,2]);
    end

    ii = inds(1);
    jj = inds(2);
    times = times + 1;
    if r(ii)>min_value && r(ii)<max_value &&...
            r(jj)>min_value && r(jj)<max_value
        r(ii) = r(ii) - 1;
        r(jj) = r(jj) + 1;
    end
end
lk = r;

end






function drawGanttChart(events, startTimes1, durations1,startTimes2, durations2,W,T,ins,Dmax)
c1 = [0 0.4470 0.7410]; 

c4 = [0 1 0];
c5 = [0.4660 0.6740 0.1880];
c6 = [0.3010 0.7450 0.9330]; 
c7 = [0.6350 0.0780 0.1840];
c8 = [0 0 0];

yfig = figure('Visible', 'off');



numEvents = length(events);

% 绘制甘特图
events_label = {}; 
for i = 1:numEvents
    % 绘制矩形条
    weapon = mod((i-1),W)+1;
    target = floor((i-1)/W)+1;
    rectangle('Position', [startTimes1(i), i, durations1(i), 0.4], 'FaceColor', c4);
    rectangle('Position', [startTimes2(i), i-0.4, durations2(i), 0.4], 'FaceColor', c5);
    events_label{i} = ['r',num2str(weapon),' to t',num2str(target)];


end


set(gca,'yticklabel',events_label);
set(gca,'ytick',1:1:numEvents);
set(gca,'xtick',0:10:Dmax);
if numEvents>=100
    set(gca,'yticklabel',events_label,'Fontsize',6);
end

set(gcf,'Position',get(0,'Screensize')); 


xlim([0, Dmax]);
ylim([0, W*T + 0.5]);
xlabel('时间(s)','FontSize',16);
ylabel('可行匹配对','FontSize',16);
title('可行匹配对及对应可行时间窗','FontSize',16);
grid on;


%% 保存图片
name1 =  ['C:\Users\lenovo\Desktop\HH\instanceTESTF\figs',num2str(ins),'.png'];
print(yfig,name1,'-dpng','-r300');         
end




